local function seat(arg)
	lua_thread.create(function()
		if not arg:match('%d+') then
			printStringNow("~R~ERROR~b~ INVALID ID", 1337)
		else
			local _, veh = sampGetCarHandleBySampVehicleId(tonumber(arg))
			if _ then
				sampSendEnterVehicle(tonumber(arg), true)
				wait(1000)
				warpCharIntoCar(playerPed, veh)
			else
				printStringNow("~r~VEH NOT IN YOUR STREAM", 1337)
			end
		end
	end)
end

function main()
	repeat
		wait(0)
	until isSampAvailable()
	wait(2000)
	sampAddChatMessage('{0C83E1}[Seat for DRP]:{FFFFFF} Loaded! Author:{0C83E1} vk.com/xeaan.{FFFFFF} Special for:{0C83E1} Yung Revenge.' ,-1)
	sampRegisterChatCommand('seat', seat)
	wait(-1)
end